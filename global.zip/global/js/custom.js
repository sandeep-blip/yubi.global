
var $window = $(window);
var $root = $('html, body');


$window.on('scroll', function () {
    headerSticky();
    skills();
    countUp();
    returnToTop();
});


function headerSticky(){

    "use strict";

    if ($window.scrollTop() > 100) {
        $('#header').addClass('header-sticky');
    } else {
        $('#header').removeClass('header-sticky');
    }
}

